﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project1
{
    public partial class UpdateAdvisor : Form
    { 
        public int aid;
        public UpdateAdvisor(int i)
        {
            InitializeComponent();
            
            aid = i;
        }

        private void comboBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox2.Text))
            {
                e.Cancel = true;
                comboBox2.Focus();
                errorProvider_Desig.SetError(comboBox2, "Please Select Designation");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Desig.SetError(comboBox2, null);
            }
        }

        private void FirstName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(FirstName.Text))
            {
                e.Cancel = true;
                FirstName.Focus();
                errorProvider_Fname.SetError(FirstName, "Please Enter Your First Name");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Fname.SetError(FirstName, null);
            }
        }

        private void Email_Validating(object sender, CancelEventArgs e)
        {
            if (!(Email.Text.Contains("@gmail.com")))
            {
                e.Cancel = true;
                Email.Focus();
                errorProvider_Email.SetError(Email, "Please Enter Valid Email");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Email.SetError(Email, null);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {

            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                var con = Configuration.getInstance().getConnection();
                //SqlCommand ID = new SqlCommand("select Advisor.Id from Advisor join Lookup on Advisor.Designation = Lookup.Id where Lookup.value = @Designation", con);
                SqlCommand ID = new SqlCommand("select Id from person where Id = @Id", con);

                ID.Parameters.AddWithValue("@Id", aid);
                int idi = Convert.ToInt32(ID.ExecuteScalar());

                SqlCommand person = new SqlCommand("update [dbo].[Person]  set FirstName = @FirstName, LastName = @LastName, Contact = @Contact, Email = @Email, DateOfBirth = @DOB, Gender = @Gender where Id = @Id;  update [dbo].[Advisor] set Designation = @Designation, Salary = @Salary where Id = @Id ", con);
                person.Parameters.AddWithValue("@Id", idi);

                SqlCommand gender = new SqlCommand("select Id from lookup where value = @value", con);
                gender.Parameters.AddWithValue("@value", comboBox1.Text);
                int gend = Convert.ToInt32(gender.ExecuteScalar());

                SqlCommand Designation = new SqlCommand("select Id from lookup where value = @value", con);
                Designation.Parameters.AddWithValue("@value", comboBox2.Text);
                int des = Convert.ToInt32(Designation.ExecuteScalar());

                person.Parameters.AddWithValue("@Designation", des);
                if(Salary.Text == "")
                {
                person.Parameters.AddWithValue("@Salary", 0);

                }
                else
                {
                    person.Parameters.AddWithValue("@Salary", int.Parse(Salary.Text));

                }
                person.Parameters.AddWithValue("@FirstName", FirstName.Text);
                person.Parameters.AddWithValue("@LastName", LastName.Text);
                person.Parameters.AddWithValue("@Contact", Contact.Text);
                person.Parameters.AddWithValue("@Email", Email.Text);
                person.Parameters.AddWithValue("@DOB", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                person.Parameters.AddWithValue("@Gender", gend);
                person.ExecuteNonQuery();
                MessageBox.Show("Successfully Updated");
                

                this.Close();
            }
        }

        private void UpdateAdvisor_Load(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand load = new SqlCommand("select * from Person join Advisor on Person.ID = Advisor.ID where Advisor.Id = @Id", con);
                load.Parameters.AddWithValue("@Id", aid);

                using (SqlDataReader sdr = load.ExecuteReader())
                {
                    sdr.Read();
                    SqlCommand desig = new SqlCommand("select value from lookup where Id = @Id", con);
                    desig.Parameters.AddWithValue("@Id", int.Parse(sdr["Designation"].ToString()));
                    FirstName.Text = sdr["FirstName"].ToString();
                    LastName.Text = sdr["LastName"].ToString();
                    Contact.Text = sdr["Contact"].ToString();
                    Email.Text = sdr["Email"].ToString();
                    dateTimePicker1.Text = sdr["DateOfBirth"].ToString();
                    SqlCommand gend = new SqlCommand("select value from lookup where Id = @Id", con);
                    gend.Parameters.AddWithValue("@Id", int.Parse(sdr["Gender"].ToString()));
                    sdr.Close();
                    string desi = Convert.ToString(desig.ExecuteScalar());
                    comboBox2.Text = desi;
                    string gender = Convert.ToString(gend.ExecuteScalar());
                    comboBox1.Text = gender;
                }
            }
            catch
            {
                MessageBox.Show("Please Selcet Advisor to update");
                this.Close();
            }
        }
    }
}
