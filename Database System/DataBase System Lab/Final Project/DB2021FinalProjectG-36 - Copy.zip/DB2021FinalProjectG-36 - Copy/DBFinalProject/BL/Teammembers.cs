﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBFinalProject.BL
{
    internal class Teammembers
    {
        int startupId;
        int role;
        string joiningdate;
    }
}
