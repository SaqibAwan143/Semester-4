﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project1.Manage_Evaluations
{
    public partial class UpdateEvalution : Form
    {
        public int id;
        public UpdateEvalution(int i)
        {
            InitializeComponent();
            id = i;
        }

        private void Name_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(Name.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                Name.Focus();
                errorProvider_Name.SetError(Name, "Please Enter Name");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Name.SetError(Name, null);
                //Add_Button.Enabled = true;

            }
        }

        private void TotalMarks_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(TotalMarks.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                TotalMarks.Focus();
                errorProvider_Marks.SetError(TotalMarks, "Please Enter Total Marks");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Marks.SetError(TotalMarks, null);
                //Add_Button.Enabled = true;

            }
        }

        private void Tot_weigt_txt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Tot_weigt_txt.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                Tot_weigt_txt.Focus();
                errorProvider_Weightage.SetError(Tot_weigt_txt, "Please Enter Total Weightage");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Weightage.SetError(Tot_weigt_txt, null);
                //Add_Button.Enabled = true;

            }
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand ID = new SqlCommand("select Id from Evaluation where Id = @Id", con);
                ID.Parameters.AddWithValue("@Id", id);
                int idi = Convert.ToInt32(ID.ExecuteScalar());

                SqlCommand person = new SqlCommand("update Evaluation set Name = @Name,TotalMarks = @TotalMarks, TotalWeightage= @TotalWeightage from Evaluation where ID = @Id", con);
                person.Parameters.AddWithValue("@Id", idi);
                
                person.Parameters.AddWithValue("@Name", Name.Text);
                person.Parameters.AddWithValue("@TotalMarks", TotalMarks.Text);
                person.Parameters.AddWithValue("@TotalWeightage", Tot_weigt_txt.Text);
                
                person.ExecuteNonQuery();


                MessageBox.Show("Successfully Updated");

                this.Close();
            }
        }

        private void UpdateEvalution_Load(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand load = new SqlCommand("select * from Evaluation where Id = @Id", con);
                load.Parameters.AddWithValue("@Id", id);
                //con.Open();
                using (SqlDataReader sdr = load.ExecuteReader())
                {
                    sdr.Read();
                    Name.Text = sdr["Name"].ToString();
                    TotalMarks.Text = sdr["TotalMarks"].ToString();
                    Tot_weigt_txt.Text = sdr["TotalWeightage"].ToString();
                    sdr.Close();
                }
            }
            catch
            {
                MessageBox.Show("Please Select Evaluation to Update");
                this.Close();
            }
        }
    }
}
