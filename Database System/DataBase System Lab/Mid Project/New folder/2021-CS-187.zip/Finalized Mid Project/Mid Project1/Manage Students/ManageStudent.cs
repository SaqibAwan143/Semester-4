﻿using Mid_Project1;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project1
{
    public partial class ManageStudent : Form
    {
        public ManageStudent()
        {
            InitializeComponent();

        }
        int id;
        Form forms;
        private void AddButton_Click(object sender, EventArgs e)
        {
            Add_Student addStudent = new Add_Student();
            addStudent.ShowDialog();
        }    
        private void ManageStudent_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from person join student on student.Id = person.id ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from person join student on student.Id = person.id ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            UpdateStudent up = new UpdateStudent(id);
            up.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        
        

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void SearchLabel_Click(object sender, EventArgs e)
        {

        }

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            //SqlCommand cmd = new SqlCommand("Select * from person join student on student.Id = person.id ", con);
            SqlDataAdapter adapt = new SqlDataAdapter("select * from person  join student on student.Id = person.id where student.RegistrationNo like '" + SearchTextBox.Text + "%'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void SearchTextBox_MouseClick(object sender, MouseEventArgs e)
        {
            
        }
        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            id = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }
    }
}
