﻿namespace DBFinalProject
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panelSideBar = new System.Windows.Forms.TableLayoutPanel();
            this.MentorBtn = new System.Windows.Forms.Button();
            this.startupsBtn = new System.Windows.Forms.Button();
            this.InvestBtn = new System.Windows.Forms.Button();
            this.AccountBtn = new System.Windows.Forms.Button();
            this.MessagesBtn = new System.Windows.Forms.Button();
            this.RequestsBtn = new System.Windows.Forms.Button();
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.panelTopBar = new System.Windows.Forms.Panel();
            this.btnCloseChildForm = new System.Windows.Forms.Button();
            this.lblTopBar = new System.Windows.Forms.Label();
            this.paneltopLeft = new System.Windows.Forms.Panel();
            this.btnSignOut = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panelSideBar.SuspendLayout();
            this.panelTopBar.SuspendLayout();
            this.paneltopLeft.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.47291F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 81.52709F));
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panelSideBar, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panelChildForm, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panelTopBar, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.paneltopLeft, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 73F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1023, 537);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightGray;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Sitka Small", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 536);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 1);
            this.label3.TabIndex = 3;
            this.label3.Text = "FYP Management System";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LightGray;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Sitka Small", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(191, 536);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(829, 1);
            this.label2.TabIndex = 2;
            this.label2.Text = "FYP Management System";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelSideBar
            // 
            this.panelSideBar.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.panelSideBar.ColumnCount = 1;
            this.panelSideBar.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.panelSideBar.Controls.Add(this.MentorBtn, 0, 6);
            this.panelSideBar.Controls.Add(this.startupsBtn, 0, 1);
            this.panelSideBar.Controls.Add(this.InvestBtn, 0, 2);
            this.panelSideBar.Controls.Add(this.AccountBtn, 0, 3);
            this.panelSideBar.Controls.Add(this.MessagesBtn, 0, 4);
            this.panelSideBar.Controls.Add(this.RequestsBtn, 0, 5);
            this.panelSideBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSideBar.Location = new System.Drawing.Point(3, 76);
            this.panelSideBar.Name = "panelSideBar";
            this.panelSideBar.RowCount = 11;
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 14F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.panelSideBar.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 9F));
            this.panelSideBar.Size = new System.Drawing.Size(182, 457);
            this.panelSideBar.TabIndex = 1;
            // 
            // MentorBtn
            // 
            this.MentorBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MentorBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MentorBtn.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MentorBtn.ForeColor = System.Drawing.Color.Wheat;
            this.MentorBtn.Location = new System.Drawing.Point(3, 361);
            this.MentorBtn.Name = "MentorBtn";
            this.MentorBtn.Size = new System.Drawing.Size(176, 56);
            this.MentorBtn.TabIndex = 6;
            this.MentorBtn.Text = "Mentor";
            this.MentorBtn.UseVisualStyleBackColor = false;
            // 
            // startupsBtn
            // 
            this.startupsBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.startupsBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.startupsBtn.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startupsBtn.ForeColor = System.Drawing.Color.Wheat;
            this.startupsBtn.Location = new System.Drawing.Point(3, 53);
            this.startupsBtn.Name = "startupsBtn";
            this.startupsBtn.Size = new System.Drawing.Size(176, 58);
            this.startupsBtn.TabIndex = 0;
            this.startupsBtn.Text = "Startups";
            this.startupsBtn.UseVisualStyleBackColor = false;
            this.startupsBtn.Click += new System.EventHandler(this.startupsBtn_Click);
            // 
            // InvestBtn
            // 
            this.InvestBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.InvestBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.InvestBtn.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InvestBtn.ForeColor = System.Drawing.Color.Wheat;
            this.InvestBtn.Location = new System.Drawing.Point(3, 117);
            this.InvestBtn.Name = "InvestBtn";
            this.InvestBtn.Size = new System.Drawing.Size(176, 54);
            this.InvestBtn.TabIndex = 1;
            this.InvestBtn.Text = "Invest";
            this.InvestBtn.UseVisualStyleBackColor = false;
            this.InvestBtn.Click += new System.EventHandler(this.InvestBtn_Click);
            // 
            // AccountBtn
            // 
            this.AccountBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AccountBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AccountBtn.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountBtn.ForeColor = System.Drawing.Color.Wheat;
            this.AccountBtn.Location = new System.Drawing.Point(3, 177);
            this.AccountBtn.Name = "AccountBtn";
            this.AccountBtn.Size = new System.Drawing.Size(176, 55);
            this.AccountBtn.TabIndex = 2;
            this.AccountBtn.Text = "Account";
            this.AccountBtn.UseVisualStyleBackColor = false;
            this.AccountBtn.Click += new System.EventHandler(this.AccountBtn_Click);
            // 
            // MessagesBtn
            // 
            this.MessagesBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MessagesBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MessagesBtn.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessagesBtn.ForeColor = System.Drawing.Color.Wheat;
            this.MessagesBtn.Location = new System.Drawing.Point(3, 238);
            this.MessagesBtn.Name = "MessagesBtn";
            this.MessagesBtn.Size = new System.Drawing.Size(176, 57);
            this.MessagesBtn.TabIndex = 3;
            this.MessagesBtn.Text = "Messages";
            this.MessagesBtn.UseVisualStyleBackColor = false;
            this.MessagesBtn.Click += new System.EventHandler(this.MessagesBtn_Click);
            // 
            // RequestsBtn
            // 
            this.RequestsBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.RequestsBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RequestsBtn.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RequestsBtn.ForeColor = System.Drawing.Color.Wheat;
            this.RequestsBtn.Location = new System.Drawing.Point(3, 301);
            this.RequestsBtn.Name = "RequestsBtn";
            this.RequestsBtn.Size = new System.Drawing.Size(176, 54);
            this.RequestsBtn.TabIndex = 5;
            this.RequestsBtn.Text = "Requests";
            this.RequestsBtn.UseVisualStyleBackColor = false;
            // 
            // panelChildForm
            // 
            this.panelChildForm.AutoSize = true;
            this.panelChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChildForm.Location = new System.Drawing.Point(191, 76);
            this.panelChildForm.Name = "panelChildForm";
            this.panelChildForm.Size = new System.Drawing.Size(829, 457);
            this.panelChildForm.TabIndex = 6;
            // 
            // panelTopBar
            // 
            this.panelTopBar.Controls.Add(this.btnCloseChildForm);
            this.panelTopBar.Controls.Add(this.lblTopBar);
            this.panelTopBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTopBar.Location = new System.Drawing.Point(191, 3);
            this.panelTopBar.Name = "panelTopBar";
            this.panelTopBar.Size = new System.Drawing.Size(829, 67);
            this.panelTopBar.TabIndex = 7;
            // 
            // btnCloseChildForm
            // 
            this.btnCloseChildForm.Location = new System.Drawing.Point(17, 18);
            this.btnCloseChildForm.Name = "btnCloseChildForm";
            this.btnCloseChildForm.Size = new System.Drawing.Size(25, 22);
            this.btnCloseChildForm.TabIndex = 1;
            this.btnCloseChildForm.Text = "X";
            this.btnCloseChildForm.UseVisualStyleBackColor = true;
            this.btnCloseChildForm.Click += new System.EventHandler(this.btnCloseChildForm_Click);
            // 
            // lblTopBar
            // 
            this.lblTopBar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTopBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTopBar.Font = new System.Drawing.Font("Nirmala UI", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTopBar.ForeColor = System.Drawing.Color.Wheat;
            this.lblTopBar.Location = new System.Drawing.Point(0, 0);
            this.lblTopBar.Name = "lblTopBar";
            this.lblTopBar.Size = new System.Drawing.Size(829, 67);
            this.lblTopBar.TabIndex = 7;
            this.lblTopBar.Text = "Startup Connect";
            this.lblTopBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paneltopLeft
            // 
            this.paneltopLeft.Controls.Add(this.btnSignOut);
            this.paneltopLeft.Location = new System.Drawing.Point(3, 3);
            this.paneltopLeft.Name = "paneltopLeft";
            this.paneltopLeft.Size = new System.Drawing.Size(182, 67);
            this.paneltopLeft.TabIndex = 8;
            // 
            // btnSignOut
            // 
            this.btnSignOut.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSignOut.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignOut.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.btnSignOut.Location = new System.Drawing.Point(3, 0);
            this.btnSignOut.Name = "btnSignOut";
            this.btnSignOut.Size = new System.Drawing.Size(123, 32);
            this.btnSignOut.TabIndex = 1;
            this.btnSignOut.Text = "Sign Out";
            this.btnSignOut.UseVisualStyleBackColor = false;
            this.btnSignOut.Click += new System.EventHandler(this.btnSignOut_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1023, 537);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "MainMenu";
            this.Text = "MainMenu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panelSideBar.ResumeLayout(false);
            this.panelTopBar.ResumeLayout(false);
            this.paneltopLeft.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel panelSideBar;
        private System.Windows.Forms.Button MentorBtn;
        private System.Windows.Forms.Button startupsBtn;
        private System.Windows.Forms.Button InvestBtn;
        private System.Windows.Forms.Button AccountBtn;
        private System.Windows.Forms.Button MessagesBtn;
        private System.Windows.Forms.Button RequestsBtn;
        private System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.Label lblTopBar;
        private System.Windows.Forms.Button btnCloseChildForm;
        private System.Windows.Forms.Panel panelTopBar;
        private System.Windows.Forms.Panel paneltopLeft;
        private System.Windows.Forms.Button btnSignOut;
    }
}