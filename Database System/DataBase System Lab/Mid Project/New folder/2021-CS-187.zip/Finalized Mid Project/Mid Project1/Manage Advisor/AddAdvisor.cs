﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project1
{
    public partial class AddAdvisor : Form
    {
        public AddAdvisor()
        {
            InitializeComponent();
        }



        private void FirstName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(FirstName.Text))
            {
                e.Cancel = true;
                FirstName.Focus();
                errorProvider_Fname.SetError(FirstName, "Please Enter Your First Name");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Fname.SetError(FirstName, null);
            }

        }

        private void Email_Validating(object sender, CancelEventArgs e)
        {
            if (!(Email.Text.Contains("@gmail.com")))
            {
                e.Cancel = true;
                Email.Focus();
                errorProvider_Email.SetError(Email, "Please Enter Valid Email");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Email.SetError(Email, null);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                if (comboBox1.Text.Contains("NULL"))
                {
                    comboBox1.Text = "Male";
                }
                var con = Configuration.getInstance().getConnection();
                SqlCommand person = new SqlCommand("Insert into Person values (@FirstName,@LastName,@Contact,@Email,@DateOfBirth,@Gender)", con);

                SqlCommand gender = new SqlCommand("select id from lookup where value = @value", con);
                gender.Parameters.AddWithValue("@value", comboBox1.Text);
                int gend = Convert.ToInt32(gender.ExecuteScalar());

                SqlCommand designatiom = new SqlCommand("select Id from lookup where value = @designation", con);
                designatiom.Parameters.AddWithValue("@designation",desig_Combo.Text);
                int desig = Convert.ToInt32(designatiom.ExecuteScalar());

                person.Parameters.AddWithValue("@FirstName", FirstName.Text);
                person.Parameters.AddWithValue("@LastName", LastName.Text);
                person.Parameters.AddWithValue("@Contact", Contact.Text);
                person.Parameters.AddWithValue("@Email", Email.Text);
                person.Parameters.AddWithValue("@DateOfBirth", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                person.Parameters.AddWithValue("@Gender", gend);

                person.ExecuteNonQuery();

                SqlCommand ID = new SqlCommand("select max(Id) from Person", con);
                int id = Convert.ToInt32(ID.ExecuteScalar());
                
                SqlCommand Advisor = new SqlCommand("Insert into Advisor values (@Id,@Designation,@Salary)", con);
                Advisor.Parameters.AddWithValue("@Id", id);
                Advisor.Parameters.AddWithValue("@Designation", desig);
                if(Salary.Text == "")
                {
                    float salary = 0;
                    Advisor.Parameters.AddWithValue("@Salary", salary);

                }
                else
                {
                    Advisor.Parameters.AddWithValue("@Salary", float.Parse(Salary.Text));

                }
                Advisor.ExecuteNonQuery();

                MessageBox.Show("Successfully saved");

                this.Close();
                //ManageStudent manage = new ManageStudent();

            }
        }

        private void comboBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(desig_Combo.Text))
            {
                e.Cancel = true;
                desig_Combo.Focus();
                errorProvider_Desig.SetError(desig_Combo, "Please Select Designation");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Desig.SetError(desig_Combo, null);
            }
        }
    }
}
