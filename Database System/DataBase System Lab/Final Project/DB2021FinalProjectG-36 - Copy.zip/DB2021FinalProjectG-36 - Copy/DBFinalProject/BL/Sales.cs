﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBFinalProject.BL
{
    internal class Sales
    {
        int startupid;
        int amount;
        int month;
        int year;

    }
}
