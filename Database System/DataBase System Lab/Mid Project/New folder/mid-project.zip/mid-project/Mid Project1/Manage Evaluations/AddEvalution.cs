﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project1.Manage_Evaluations
{
    public partial class AddEvalution : Form
    {
        public AddEvalution()
        {
            InitializeComponent();
        }

        private void Name_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Name.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                Name.Focus();
                errorProvider_Name .SetError(Name, "Please Enter Name");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Name.SetError(Name, null);
                //Add_Button.Enabled = true;

            }
        }

        private void LastName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(TotalMarks.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                TotalMarks .Focus();
                errorProvider_Marks.SetError(TotalMarks, "Please Enter Title");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Marks.SetError(TotalMarks, null);
                //Add_Button.Enabled = true;

            }
        }

        private void Tot_weigt_txt_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Tot_weigt_txt.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                Tot_weigt_txt.Focus();
                errorProvider_Weightage.SetError(Tot_weigt_txt, "Please Enter Total Weightage");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Weightage.SetError(Tot_weigt_txt, null);
                //Add_Button.Enabled = true;

            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                
                var con = Configuration.getInstance().getConnection();
                SqlCommand person = new SqlCommand("Insert into Evaluation values (@Name,@TotalMarks,@TotalWeightage)", con);

               
                person.Parameters.AddWithValue("@Name", Name.Text);
                person.Parameters.AddWithValue("@TotalMarks", TotalMarks.Text);
                person.Parameters.AddWithValue("@TotalWeightage", Tot_weigt_txt.Text);
                person.ExecuteNonQuery();

                MessageBox.Show("Successfully saved");

                this.Close();
                

            }
        }
    }
}
