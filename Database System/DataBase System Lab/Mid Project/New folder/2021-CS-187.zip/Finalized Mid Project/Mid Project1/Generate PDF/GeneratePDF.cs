﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.qrcode;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Mid_Project1.Generate_PDF
{
    public partial class GeneratePDF : Form
    {
        public GeneratePDF()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select P1.Id , P1.FirstName , P1.LastName ,L.Value as Gender, P1.Contact , P1.Email , P1.DateOfBirth , P1.Designation , P1.Salary from Lookup as L join (select A.Id, A.Salary, P.FirstName , P.LastName , P.Contact , P.Email , P.DateOfBirth , L.Value as Designation , P.Gender from Advisor as A join Person  as P on P.Id = A.Id join Lookup as L on L.Id = A.Designation) as P1 on P1.Gender = L.Id");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);

            if (dataTable.Rows.Count > 0)

            {

                SaveFileDialog save = new SaveFileDialog();

                save.Filter = "PDF (.pdf)|.pdf";

                save.FileName = "StudentsReport1.pdf";

                bool ErrorMessage = false;


                if (File.Exists(save.FileName))

                {

                    try

                    {

                        File.Delete(save.FileName);

                    }

                    catch (Exception ex)

                    {

                        ErrorMessage = true;

                        MessageBox.Show("Unable to wride data in disk" + ex.Message);

                    }

                }

                if (!ErrorMessage)

                {

                    try

                    {

                        PdfPTable AllStudents = new PdfPTable(dataTable.Columns.Count);
                        AllStudents.DefaultCell.Padding = 2;

                        AllStudents.WidthPercentage = 100;

                        AllStudents.HorizontalAlignment = Element.ALIGN_LEFT;

                        for (int i = 0; i < dataTable.Columns.Count; i++)
                        {
                            PdfPCell cell = new PdfPCell(new Phrase(dataTable.Columns[i].ColumnName));
                            AllStudents.AddCell(cell);
                        }
                        for (int i = 0; i < dataTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < dataTable.Columns.Count; j++)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(dataTable.Rows[i][j].ToString()));
                                AllStudents.AddCell(cell);
                            }
                        }

                        using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))
                        {

                            iTextSharp.text.Document document = new iTextSharp.text.Document(PageSize.A4, 8f, 16f, 16f, 8f);

                            PdfWriter.GetInstance(document, fileStream);

                            document.Open();

                            document.Add(AllStudents);

                            document.Close();

                            fileStream.Close();

                        }

                        MessageBox.Show("Data Export Successfully", "info");

                    }

                    catch (Exception ex)

                    {

                        MessageBox.Show("Error while exporting Data" + ex.Message);

                    }

                }

            }



            else

            {

                MessageBox.Show("No Record Found", "Info");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT \r\n    p.id AS project_id, \r\n    p.title AS project_title, \r\n    s.id AS student_id, \r\n    CONCAT(per.firstname, ' ', per.lastname) AS student_name,\r\n    e.id AS evaluation_id,\r\n    e.name AS evaluation_name,\r\n    ge.obtainedmarks AS marks_obtained,\r\n    SUM(ge.obtainedmarks) OVER(PARTITION BY p.id, s.id) AS total_marks\r\nFROM \r\n    project AS p \r\n    INNER JOIN groupProject AS gp ON p.id = gp.ProjectId \r\n    INNER JOIN groupStudent AS gs ON gp.groupId = gs.groupId \r\n    INNER JOIN student AS s ON gs.studentId = s.id \r\n    INNER JOIN person AS per ON s.id = per.id \r\n    INNER JOIN GroupEvaluation AS ge ON gp.groupId = ge.groupid \r\n    INNER JOIN evaluation AS e ON ge.evaluationID = e.id\r\nORDER BY \r\n    p.id, s.id, e.id;");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);

            if (dataTable.Rows.Count > 0)

            {

                SaveFileDialog save = new SaveFileDialog();

                save.Filter = "PDF (.pdf)|.pdf";

                save.FileName = "StudentsReport2.pdf";

                bool ErrorMessage = false;


                if (File.Exists(save.FileName))

                {

                    try

                    {

                        File.Delete(save.FileName);

                    }

                    catch (Exception ex)

                    {

                        ErrorMessage = true;

                        MessageBox.Show("Unable to wride data in disk" + ex.Message);

                    }

                }

                if (!ErrorMessage)

                {

                    try

                    {

                        PdfPTable AllStudents = new PdfPTable(dataTable.Columns.Count);

                        AllStudents.DefaultCell.Padding = 2;

                        AllStudents.WidthPercentage = 100;

                        AllStudents.HorizontalAlignment = Element.ALIGN_LEFT;

                        for (int i = 0; i < dataTable.Columns.Count; i++)
                        {
                            PdfPCell cell = new PdfPCell(new Phrase(dataTable.Columns[i].ColumnName));
                            AllStudents.AddCell(cell);
                        }
                        for (int i = 0; i < dataTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < dataTable.Columns.Count; j++)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(dataTable.Rows[i][j].ToString()));
                                AllStudents.AddCell(cell);
                            }
                        }

                        using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))

                        {

                            iTextSharp.text.Document document = new iTextSharp.text.Document(PageSize.A4, 8f, 16f, 16f, 8f);

                            PdfWriter.GetInstance(document, fileStream);

                            document.Open();

                            document.Add(AllStudents);

                            document.Close();

                            fileStream.Close();

                        }

                        MessageBox.Show("Data Export Successfully", "info");

                    }

                    catch (Exception ex)

                    {

                        MessageBox.Show("Error while exporting Data" + ex.Message);

                    }

                }

            }



            else

            {

                MessageBox.Show("No Record Found", "Info");

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select S.Id, S.RegistrationNo, FirstName, LastName, Contact, Email\r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id EXCEPT select S.Id, S.RegistrationNo, P.FirstName, P.LastName, P.Contact, P.Email\r\nfrom[dbo].[Group] as G\r\njoin[dbo].GroupStudent as Gs\r\non Gs.GroupId = G.Id\r\njoin Lookup as L\r\non L.Id = Gs.Status\r\njoin Person as P\r\non P.Id = Gs.StudentId\r\njoin Student as S\r\non S.Id = P.Id\r\nwhere L.Value = 'Active'");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            if (dataTable.Rows.Count > 0)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "PDF (.pdf)|.pdf";
                save.FileName = "Report3.pdf";
                bool ErrorMessage = false;
                if (File.Exists(save.FileName))
                {
                    try
                    {
                        File.Delete(save.FileName);
                    }
                    catch (Exception ex)
                    {
                        ErrorMessage = true;
                        MessageBox.Show("Unable to wride data in disk" + ex.Message);

                    }

                }

                if (!ErrorMessage)

                {

                    try

                    {

                        PdfPTable AllStudents = new PdfPTable(dataTable.Columns.Count);

                        AllStudents.DefaultCell.Padding = 2;

                        AllStudents.WidthPercentage = 100;

                        AllStudents.HorizontalAlignment = Element.ALIGN_LEFT;

                        for (int i = 0; i < dataTable.Columns.Count; i++)
                        {
                            PdfPCell cell = new PdfPCell(new Phrase(dataTable.Columns[i].ColumnName));
                            AllStudents.AddCell(cell);
                        }
                        for (int i = 0; i < dataTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < dataTable.Columns.Count; j++)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(dataTable.Rows[i][j].ToString()));
                                AllStudents.AddCell(cell);
                            }
                        }

                        using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))

                        {

                            iTextSharp.text.Document document = new iTextSharp.text.Document(PageSize.A4, 8f, 16f, 16f, 8f);

                            PdfWriter.GetInstance(document, fileStream);

                            document.Open();

                            document.Add(AllStudents);

                            document.Close();

                            fileStream.Close();

                        }

                        MessageBox.Show("Data Export Successfully", "info");

                    }

                    catch (Exception ex)

                    {

                        MessageBox.Show("Error while exporting Data" + ex.Message);

                    }

                }

            }



            else

            {

                MessageBox.Show("No Record Found", "Info");

            }
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select GroupId,StudentId from GroupStudent except select GroupId,ProjectId from GroupProject\r\n");
            cmd.Connection = con;
            SqlDataReader sqlData = cmd.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlData);
            if (dataTable.Rows.Count > 0)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "PDF (.pdf)|.pdf";
                save.FileName = "Report4.pdf";
                bool ErrorMessage = false;
                if (File.Exists(save.FileName))
                {
                    try
                    {
                        File.Delete(save.FileName);
                    }
                    catch (Exception ex)
                    {
                        ErrorMessage = true;
                        MessageBox.Show("Unable to wride data in disk" + ex.Message);

                    }

                }

                if (!ErrorMessage)

                {

                    try

                    {

                        PdfPTable AllStudents = new PdfPTable(dataTable.Columns.Count);

                        AllStudents.DefaultCell.Padding = 2;

                        AllStudents.WidthPercentage = 100;

                        AllStudents.HorizontalAlignment = Element.ALIGN_LEFT;

                        for (int i = 0; i < dataTable.Columns.Count; i++)
                        {
                            PdfPCell cell = new PdfPCell(new Phrase(dataTable.Columns[i].ColumnName));
                            AllStudents.AddCell(cell);
                        }
                        for (int i = 0; i < dataTable.Rows.Count; i++)
                        {
                            for (int j = 0; j < dataTable.Columns.Count; j++)
                            {
                                PdfPCell cell = new PdfPCell(new Phrase(dataTable.Rows[i][j].ToString()));
                                AllStudents.AddCell(cell);
                            }
                        }

                        using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))

                        {

                            iTextSharp.text.Document document = new iTextSharp.text.Document(PageSize.A4, 8f, 16f, 16f, 8f);

                            PdfWriter.GetInstance(document, fileStream);

                            document.Open();

                            document.Add(AllStudents);

                            document.Close();

                            fileStream.Close();

                        }

                        MessageBox.Show("Data Export Successfully", "info");

                    }

                    catch (Exception ex)

                    {

                        MessageBox.Show("Error while exporting Data" + ex.Message);

                    }

                }

            }



            else

            {

                MessageBox.Show("No Record Found", "Info");

            }
        }
    }
}

