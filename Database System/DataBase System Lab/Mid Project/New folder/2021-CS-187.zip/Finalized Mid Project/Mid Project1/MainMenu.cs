﻿using Mid_Project1.Groups;
using Mid_Project1.Manage_Advisor;
using Mid_Project1.Manage_Evaluations;
using Mid_Project1.Manage_Projects;
using Mid_Project1.Generate_PDF;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project1
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }
        public static Form forms;
        
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (forms == null)
            {
                ManageStudent objForm = new ManageStudent();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if(forms != null)
            {
                forms.Close();
                ManageStudent objForm = new ManageStudent();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(forms != null)
            {
                forms.Close();
                ManageAdvisors objForm = new ManageAdvisors();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if(forms == null)
            {
                ManageAdvisors objForm = new ManageAdvisors();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                ManageProjects objForm = new ManageProjects();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if (forms == null)
            {
                ManageProjects objForm = new ManageProjects();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                ManageEvaluations objForm = new ManageEvaluations();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if (forms == null)
            {
                ManageEvaluations objForm = new ManageEvaluations();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                ManageStudentGroup objForm = new ManageStudentGroup();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if (forms == null)
            {
                ManageStudentGroup objForm = new ManageStudentGroup();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void MakeGroup_Button_Click(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                MakeGroups objForm = new MakeGroups();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if (forms == null)
            {
                MakeGroups objForm = new MakeGroups();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                AssignProjects objForm = new AssignProjects();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if (forms == null)
            {
                AssignProjects objForm = new AssignProjects();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void Assign_ADvisor_button_Click(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                AssignAdvisors objForm = new AssignAdvisors();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if (forms == null)
            {
                AssignAdvisors objForm = new AssignAdvisors();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void Grp_Evaluation_Button_Click(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                GroupEvaluation objForm = new GroupEvaluation();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
            else if (forms == null)
            {
                GroupEvaluation objForm = new GroupEvaluation();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
            }
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (forms != null)
            {
                forms.Close();
                GeneratePDF objForm = new GeneratePDF();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
                objForm.BringToFront();
            }
            else if (forms == null)
            {
                GeneratePDF objForm = new GeneratePDF();
                forms = objForm;
                this.IsMdiContainer = true;
                objForm.TopLevel = false;
                this.panel1.Controls.Add(objForm);
                objForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                objForm.Dock = DockStyle.Fill;
                objForm.Show();
                objForm.BringToFront();
            }
        }
    }
    }

