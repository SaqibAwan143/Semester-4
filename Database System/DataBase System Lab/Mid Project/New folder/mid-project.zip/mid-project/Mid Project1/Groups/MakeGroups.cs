﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project1.Groups
{
    public partial class MakeGroups : Form
    {
        public MakeGroups()
        {
            InitializeComponent();
        }
        public int S_Id;
        private void Button_GroupCreate_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand group = new SqlCommand("Insert into dbo.[Group] values (@Created_On)", con);

            group.Parameters.AddWithValue("@Created_on", dateTimePicker2.Value.ToString("MM/dd/yyyy"));
            
            group.ExecuteNonQuery();
            this.Refresh();
        }

        public void GroupDataload()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select * from dbo.[Group]", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        public void GroupIdLoad()
        {
            var con = Configuration.getInstance().getConnection();
            SqlDataReader myReader1 = null;
            SqlCommand myCommand1 = new SqlCommand("select Id from dbo.[Group]", con);
            myReader1 = myCommand1.ExecuteReader();
            while (myReader1.Read())
            {
                comboBox1.Items.Add((int)myReader1["Id"]);
            }
            myReader1.Close();
            
        }
        public void load_Student_Data()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select S.Id, S.RegistrationNo , FirstName , LastName , Contact , Email\r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id EXCEPT select S.Id , S.RegistrationNo , P.FirstName , P.LastName , P.Contact , P.Email\r\nfrom [dbo].[Group] as G\r\njoin [dbo].GroupStudent as Gs\r\non Gs.GroupId = G.Id\r\njoin Lookup as L\r\non L.Id = Gs.Status\r\njoin Person as P\r\non P.Id = Gs.StudentId\r\njoin Student as S\r\non S.Id = P.Id\r\nwhere L.Value = 'Active'", con);
            //int value = 3;
            //SqlCommand cmd = new SqlCommand("select * from dbo.[GroupStudent]", con);

            //cmd.Parameters.AddWithValue("@Value", value);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void MakeGroups_Load(object sender, EventArgs e)
        {
           // GroupDataload();
            GroupIdLoad();
            load_Student_Data();
        }

        private void Refresh_Button_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            GroupIdLoad();
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("select S.Id, S.RegistrationNo , FirstName , LastName , Contact , Email\r\nfrom Student as S\r\njoin Person as P\r\non S.Id = P.Id EXCEPT select S.Id , S.RegistrationNo , P.FirstName , P.LastName , P.Contact , P.Email\r\nfrom [dbo].[Group] as G\r\njoin [dbo].GroupStudent as Gs\r\non Gs.GroupId = G.Id\r\njoin Lookup as L\r\non L.Id = Gs.Status\r\njoin Person as P\r\non P.Id = Gs.StudentId\r\njoin Student as S\r\non S.Id = P.Id\r\nwhere L.Value = 'Active'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Create_STD_Group_Button_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {

                var con = Configuration.getInstance().getConnection();

                SqlCommand status = new SqlCommand("select id from lookup where value = @value", con);
                status.Parameters.AddWithValue("@value", comboBox2.Text);
                int stat = Convert.ToInt32(status.ExecuteScalar());

                SqlCommand group = new SqlCommand("Insert into dbo.[GroupStudent] values (@GroupId,@StudentId,@Status,@AssignmentDate)", con);
                group.Parameters.AddWithValue("@GroupId", int.Parse(comboBox1.Text));
                group.Parameters.AddWithValue("@StudentId", S_Id);
                group.Parameters.AddWithValue("@Status", stat);
                group.Parameters.AddWithValue("@AssignmentDate", dateTimePicker1.Value.ToString("MM/dd/yyyy"));

                group.ExecuteNonQuery();
                Refresh_Button_Click(sender, e);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox2.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                comboBox2.Focus();
                errorProvider1.SetError(comboBox2, "Please Select Student Status");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(comboBox2, null);
                //Add_Button.Enabled = true;

            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            S_Id = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }

        private void comboBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox1.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                comboBox1.Focus();
                errorProvider2.SetError(comboBox1, "Please Select Group ID");
            }
            else
            {
                e.Cancel = false;
                errorProvider2.SetError(comboBox1, null);
                //Add_Button.Enabled = true;
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewGroup view = new ViewGroup();
            view.ShowDialog();
        }
    }
}
