﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DBFinalProject.Extras;
namespace DBFinalProject
{
    public partial class MainMenu : Form
    {
        private Button currentButton;
        private Random random = new Random();
        private int tempIndex;
        private Form activeForm;
        public MainMenu()
        {
            InitializeComponent();
            btnCloseChildForm.Visible = false;
        }
        private void activateButton(object sender)
        {
            if (sender != null)
            {
                if (currentButton != (Button)sender)
                {
                    deactivateButton();
                    Color color = selectColor();
                    currentButton = (Button)sender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.WhiteSmoke;
                    currentButton.Font = new System.Drawing.Font("Lucida Fax", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    panelTopBar.BackColor = color;
                    Color backColor = ThemeColor.ChangeColorBrightness(color, 0.3);
                //    paneltopLeft.BackColor = backColor;
                    ThemeColor.PrimaryColor = color;
                    ThemeColor.SecondaryColor = backColor;
                }
            }
        }
        private Color selectColor()
        {

            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void deactivateButton()
        {
            foreach (Control control in panelSideBar.Controls)
            {
                if (control.GetType() == typeof(Button))
                {
                    control.BackColor = SystemColors.ActiveCaptionText;
                    control.ForeColor = Color.Wheat;
                    control.Font = new System.Drawing.Font("Lucida Fax", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }
        public void openCildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelChildForm.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
            lblTopBar.Text = childForm.Text;
            btnCloseChildForm.Visible = true;
        }
        private void btnCloseChildForm_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
            {
                activeForm.Close();

            }
            reset();
        }
        private void reset()
        {
            deactivateButton();
            lblTopBar.Text = "Startup Connect";
            panelTopBar.BackColor = Color.FromArgb(160, 160, 160);
          //  paneltopLeft.BackColor = Color.FromArgb(188, 188, 188);
            currentButton = null;
            btnCloseChildForm.Visible = false;
        }
        private void panelTopBar_MouseDown(object sender, MouseEventArgs e)
        {
            Extras.Drag.dragPage(this);
        }

        private void startupsBtn_Click(object sender, EventArgs e)
        {
            openCildForm(new Startups(), sender);
        }

        private void InvestBtn_Click(object sender, EventArgs e)
        {
            openCildForm(new Investors(), sender);
        }

        private void AccountBtn_Click(object sender, EventArgs e)
        {
            openCildForm(new AccountDetails(), sender);
        }

        private void MessagesBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSignOut_Click(object sender, EventArgs e)
        {
            Form form = new SignIn();
            form.Show();
            this.Hide();
        }
    }
}
