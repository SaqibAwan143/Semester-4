﻿namespace Mid_Project1
{
    partial class Add_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.FName_lbl = new System.Windows.Forms.Label();
            this.L_Name_LBL = new System.Windows.Forms.Label();
            this.Contact_LBL = new System.Windows.Forms.Label();
            this.Email_LBL = new System.Windows.Forms.Label();
            this.DOB_LBL = new System.Windows.Forms.Label();
            this.Gender_LBL = new System.Windows.Forms.Label();
            this.RegNO_BOX = new System.Windows.Forms.TextBox();
            this.Fname_Box = new System.Windows.Forms.TextBox();
            this.Lname_Box = new System.Windows.Forms.TextBox();
            this.Contact_Box = new System.Windows.Forms.TextBox();
            this.Email_Box = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Regno_eroor_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Add_Button = new System.Windows.Forms.Button();
            this.errorProvider_regno = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Fname = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Email = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_regno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Fname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Email)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.FName_lbl, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.L_Name_LBL, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.Contact_LBL, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.Email_LBL, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.DOB_LBL, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.Gender_LBL, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.RegNO_BOX, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.Fname_Box, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.Lname_Box, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.Contact_Box, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.Email_Box, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker1, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.Regno_eroor_lbl, 6, 2);
            this.tableLayoutPanel1.Controls.Add(this.label1, 6, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 6, 6);
            this.tableLayoutPanel1.Controls.Add(this.Add_Button, 8, 8);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(953, 518);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.label2, 2);
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(98, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 65);
            this.label2.TabIndex = 1;
            this.label2.Text = "Registration NO";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FName_lbl
            // 
            this.FName_lbl.AutoSize = true;
            this.FName_lbl.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.FName_lbl, 2);
            this.FName_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FName_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FName_lbl.Location = new System.Drawing.Point(98, 106);
            this.FName_lbl.Name = "FName_lbl";
            this.FName_lbl.Size = new System.Drawing.Size(184, 65);
            this.FName_lbl.TabIndex = 2;
            this.FName_lbl.Text = "First Name";
            this.FName_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // L_Name_LBL
            // 
            this.L_Name_LBL.AutoSize = true;
            this.L_Name_LBL.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.L_Name_LBL, 2);
            this.L_Name_LBL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.L_Name_LBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L_Name_LBL.Location = new System.Drawing.Point(98, 171);
            this.L_Name_LBL.Name = "L_Name_LBL";
            this.L_Name_LBL.Size = new System.Drawing.Size(184, 65);
            this.L_Name_LBL.TabIndex = 3;
            this.L_Name_LBL.Text = "Last Name";
            this.L_Name_LBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Contact_LBL
            // 
            this.Contact_LBL.AutoSize = true;
            this.Contact_LBL.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.Contact_LBL, 2);
            this.Contact_LBL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Contact_LBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contact_LBL.Location = new System.Drawing.Point(98, 236);
            this.Contact_LBL.Name = "Contact_LBL";
            this.Contact_LBL.Size = new System.Drawing.Size(184, 65);
            this.Contact_LBL.TabIndex = 4;
            this.Contact_LBL.Text = "Contact";
            this.Contact_LBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Email_LBL
            // 
            this.Email_LBL.AutoSize = true;
            this.Email_LBL.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.Email_LBL, 2);
            this.Email_LBL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Email_LBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_LBL.Location = new System.Drawing.Point(98, 301);
            this.Email_LBL.Name = "Email_LBL";
            this.Email_LBL.Size = new System.Drawing.Size(184, 65);
            this.Email_LBL.TabIndex = 5;
            this.Email_LBL.Text = "Email";
            this.Email_LBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DOB_LBL
            // 
            this.DOB_LBL.AutoSize = true;
            this.DOB_LBL.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.DOB_LBL, 2);
            this.DOB_LBL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DOB_LBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DOB_LBL.Location = new System.Drawing.Point(98, 366);
            this.DOB_LBL.Name = "DOB_LBL";
            this.DOB_LBL.Size = new System.Drawing.Size(184, 65);
            this.DOB_LBL.TabIndex = 6;
            this.DOB_LBL.Text = "Date Of Birth";
            this.DOB_LBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Gender_LBL
            // 
            this.Gender_LBL.AutoSize = true;
            this.Gender_LBL.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.Gender_LBL, 2);
            this.Gender_LBL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Gender_LBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gender_LBL.Location = new System.Drawing.Point(98, 431);
            this.Gender_LBL.Name = "Gender_LBL";
            this.Gender_LBL.Size = new System.Drawing.Size(184, 65);
            this.Gender_LBL.TabIndex = 7;
            this.Gender_LBL.Text = "Gender";
            this.Gender_LBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RegNO_BOX
            // 
            this.RegNO_BOX.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.SetColumnSpan(this.RegNO_BOX, 3);
            this.RegNO_BOX.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegNO_BOX.Location = new System.Drawing.Point(301, 59);
            this.RegNO_BOX.Name = "RegNO_BOX";
            this.RegNO_BOX.Size = new System.Drawing.Size(253, 29);
            this.RegNO_BOX.TabIndex = 9;
            this.RegNO_BOX.TextChanged += new System.EventHandler(this.RegNO_BOX_TextChanged);
            this.RegNO_BOX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.RegNO_BOX_KeyPress);
            this.RegNO_BOX.Validating += new System.ComponentModel.CancelEventHandler(this.RegNO_BOX_Validating);
            // 
            // Fname_Box
            // 
            this.Fname_Box.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.SetColumnSpan(this.Fname_Box, 3);
            this.Fname_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fname_Box.Location = new System.Drawing.Point(301, 124);
            this.Fname_Box.Name = "Fname_Box";
            this.Fname_Box.Size = new System.Drawing.Size(253, 29);
            this.Fname_Box.TabIndex = 10;
            this.Fname_Box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Fname_Box_KeyPress);
            this.Fname_Box.Validating += new System.ComponentModel.CancelEventHandler(this.Fname_Box_Validating);
            // 
            // Lname_Box
            // 
            this.Lname_Box.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.SetColumnSpan(this.Lname_Box, 3);
            this.Lname_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lname_Box.Location = new System.Drawing.Point(301, 189);
            this.Lname_Box.Name = "Lname_Box";
            this.Lname_Box.Size = new System.Drawing.Size(253, 29);
            this.Lname_Box.TabIndex = 11;
            // 
            // Contact_Box
            // 
            this.Contact_Box.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.SetColumnSpan(this.Contact_Box, 3);
            this.Contact_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contact_Box.Location = new System.Drawing.Point(301, 254);
            this.Contact_Box.Name = "Contact_Box";
            this.Contact_Box.Size = new System.Drawing.Size(253, 29);
            this.Contact_Box.TabIndex = 12;
            // 
            // Email_Box
            // 
            this.Email_Box.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.SetColumnSpan(this.Email_Box, 3);
            this.Email_Box.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_Box.Location = new System.Drawing.Point(301, 319);
            this.Email_Box.Name = "Email_Box";
            this.Email_Box.Size = new System.Drawing.Size(253, 29);
            this.Email_Box.TabIndex = 13;
            this.Email_Box.Leave += new System.EventHandler(this.Email_Box_Leave);
            this.Email_Box.Validating += new System.ComponentModel.CancelEventHandler(this.Email_Box_Validating);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.SetColumnSpan(this.dateTimePicker1, 3);
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(301, 386);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(253, 24);
            this.dateTimePicker1.TabIndex = 14;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.SetColumnSpan(this.comboBox1, 3);
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Male",
            "Female",
            "NULL"});
            this.comboBox1.Location = new System.Drawing.Point(301, 447);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(253, 32);
            this.comboBox1.TabIndex = 15;
            // 
            // Regno_eroor_lbl
            // 
            this.Regno_eroor_lbl.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.Regno_eroor_lbl, 4);
            this.Regno_eroor_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Regno_eroor_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Regno_eroor_lbl.ForeColor = System.Drawing.Color.Red;
            this.Regno_eroor_lbl.Location = new System.Drawing.Point(573, 41);
            this.Regno_eroor_lbl.Name = "Regno_eroor_lbl";
            this.Regno_eroor_lbl.Size = new System.Drawing.Size(377, 65);
            this.Regno_eroor_lbl.TabIndex = 17;
            this.Regno_eroor_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label1, 4);
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(573, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(377, 65);
            this.label1.TabIndex = 18;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label3, 4);
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(573, 301);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(377, 65);
            this.label3.TabIndex = 19;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Add_Button
            // 
            this.Add_Button.BackColor = System.Drawing.Color.Yellow;
            this.tableLayoutPanel1.SetColumnSpan(this.Add_Button, 2);
            this.Add_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Button.ForeColor = System.Drawing.Color.Black;
            this.Add_Button.Location = new System.Drawing.Point(763, 434);
            this.Add_Button.Name = "Add_Button";
            this.Add_Button.Size = new System.Drawing.Size(178, 59);
            this.Add_Button.TabIndex = 20;
            this.Add_Button.Text = "Add";
            this.Add_Button.UseVisualStyleBackColor = false;
            this.Add_Button.Click += new System.EventHandler(this.Add_Button_Click);
            // 
            // errorProvider_regno
            // 
            this.errorProvider_regno.ContainerControl = this;
            // 
            // errorProvider_Fname
            // 
            this.errorProvider_Fname.ContainerControl = this;
            // 
            // errorProvider_Email
            // 
            this.errorProvider_Email.ContainerControl = this;
            // 
            // Add_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 518);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Add_Student";
            this.Text = "Add_Student";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_regno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Fname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Email)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label FName_lbl;
        private System.Windows.Forms.Label L_Name_LBL;
        private System.Windows.Forms.Label Contact_LBL;
        private System.Windows.Forms.Label Email_LBL;
        private System.Windows.Forms.Label DOB_LBL;
        private System.Windows.Forms.Label Gender_LBL;
        private System.Windows.Forms.TextBox RegNO_BOX;
        private System.Windows.Forms.TextBox Fname_Box;
        private System.Windows.Forms.TextBox Lname_Box;
        private System.Windows.Forms.TextBox Contact_Box;
        private System.Windows.Forms.TextBox Email_Box;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label Regno_eroor_lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Add_Button;
        private System.Windows.Forms.ErrorProvider errorProvider_regno;
        private System.Windows.Forms.ErrorProvider errorProvider_Fname;
        private System.Windows.Forms.ErrorProvider errorProvider_Email;
    }
}