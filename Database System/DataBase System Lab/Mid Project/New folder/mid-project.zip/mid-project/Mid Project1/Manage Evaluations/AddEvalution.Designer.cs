﻿namespace Mid_Project1.Manage_Evaluations
{
    partial class AddEvalution
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.errorProvider_Name = new System.Windows.Forms.ErrorProvider(this.components);
            this.NameLabel = new System.Windows.Forms.Label();
            this.TotalMarks_label = new System.Windows.Forms.Label();
            this.ContLabel = new System.Windows.Forms.Label();
            this.Name = new System.Windows.Forms.TextBox();
            this.TotalMarks = new System.Windows.Forms.TextBox();
            this.errorProvider_Marks = new System.Windows.Forms.ErrorProvider(this.components);
            this.AddButton = new System.Windows.Forms.Button();
            this.Tot_weigt_txt = new System.Windows.Forms.TextBox();
            this.errorProvider_Weightage = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Name)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Marks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Weightage)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // errorProvider_Name
            // 
            this.errorProvider_Name.ContainerControl = this;
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.NameLabel, 2);
            this.NameLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.NameLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.Location = new System.Drawing.Point(80, 90);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(148, 45);
            this.NameLabel.TabIndex = 2;
            this.NameLabel.Text = "Name";
            this.NameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TotalMarks_label
            // 
            this.TotalMarks_label.AutoSize = true;
            this.TotalMarks_label.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.TotalMarks_label, 2);
            this.TotalMarks_label.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TotalMarks_label.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalMarks_label.Location = new System.Drawing.Point(80, 135);
            this.TotalMarks_label.Name = "TotalMarks_label";
            this.TotalMarks_label.Size = new System.Drawing.Size(148, 45);
            this.TotalMarks_label.TabIndex = 3;
            this.TotalMarks_label.Text = "Total Marks";
            this.TotalMarks_label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ContLabel
            // 
            this.ContLabel.AutoSize = true;
            this.ContLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.ContLabel, 2);
            this.ContLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContLabel.Location = new System.Drawing.Point(80, 180);
            this.ContLabel.Name = "ContLabel";
            this.ContLabel.Size = new System.Drawing.Size(148, 45);
            this.ContLabel.TabIndex = 4;
            this.ContLabel.Text = "Total Weigtage\r\n\r\n";
            this.ContLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Name
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.Name, 3);
            this.Name.Dock = System.Windows.Forms.DockStyle.Right;
            this.Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name.Location = new System.Drawing.Point(237, 93);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(222, 29);
            this.Name.TabIndex = 10;
            this.Name.Validating += new System.ComponentModel.CancelEventHandler(this.Name_Validating);
            // 
            // TotalMarks
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.TotalMarks, 3);
            this.TotalMarks.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalMarks.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalMarks.Location = new System.Drawing.Point(237, 138);
            this.TotalMarks.Name = "TotalMarks";
            this.TotalMarks.Size = new System.Drawing.Size(222, 29);
            this.TotalMarks.TabIndex = 11;
            this.TotalMarks.Validating += new System.ComponentModel.CancelEventHandler(this.LastName_Validating);
            // 
            // errorProvider_Marks
            // 
            this.errorProvider_Marks.ContainerControl = this;
            // 
            // AddButton
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.AddButton, 2);
            this.AddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddButton.Location = new System.Drawing.Point(465, 228);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(139, 39);
            this.AddButton.TabIndex = 18;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // Tot_weigt_txt
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.Tot_weigt_txt, 3);
            this.Tot_weigt_txt.Dock = System.Windows.Forms.DockStyle.Right;
            this.Tot_weigt_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tot_weigt_txt.Location = new System.Drawing.Point(237, 183);
            this.Tot_weigt_txt.Name = "Tot_weigt_txt";
            this.Tot_weigt_txt.Size = new System.Drawing.Size(222, 29);
            this.Tot_weigt_txt.TabIndex = 12;
            this.Tot_weigt_txt.Validating += new System.ComponentModel.CancelEventHandler(this.Tot_weigt_txt_Validating);
            // 
            // errorProvider_Weightage
            // 
            this.errorProvider_Weightage.ContainerControl = this;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.NameLabel, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.TotalMarks_label, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.ContLabel, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.Name, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.TotalMarks, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.Tot_weigt_txt, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.AddButton, 6, 5);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(770, 456);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // AddEvalution
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 456);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Text = "AddEvalution";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Name)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Marks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Weightage)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ErrorProvider errorProvider_Name;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label TotalMarks_label;
        private System.Windows.Forms.Label ContLabel;
        private System.Windows.Forms.TextBox Name;
        private System.Windows.Forms.TextBox TotalMarks;
        private System.Windows.Forms.TextBox Tot_weigt_txt;
        private System.Windows.Forms.ErrorProvider errorProvider_Marks;
        private System.Windows.Forms.ErrorProvider errorProvider_Weightage;
    }
}