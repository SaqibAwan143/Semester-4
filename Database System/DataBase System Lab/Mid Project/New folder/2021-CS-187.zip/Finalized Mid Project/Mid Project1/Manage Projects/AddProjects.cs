﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project1
{
    public partial class AddProjects : Form
    {
        public AddProjects()
        {
            InitializeComponent();
        }

      

        private void Salary_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(title.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                title.Focus();
                errorProvider.SetError(title, "Please Enter Title");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(title, null);
                //Add_Button.Enabled = true;

            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand person = new SqlCommand("Insert into Project values (@Description,@Title)", con);

            person.Parameters.AddWithValue("@Description", richTextBox1.Text);
            person.Parameters.AddWithValue("@Title", title.Text);
            person.ExecuteNonQuery();

            

            MessageBox.Show("Successfully saved");

            this.Close();
        }
    }
}
