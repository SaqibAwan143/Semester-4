﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project1
{
    public partial class UpdateStudent : Form
    {
        public int id = 0;
        public UpdateStudent(int i)
        {
            InitializeComponent();
            id = i;             
        }
        
        private void Update_Button_Click(object sender, EventArgs e)
        {

            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand ID = new SqlCommand("select Id from Student where RegistrationNo = @RegistrationNo", con);
                ID.Parameters.AddWithValue("@RegistrationNo", RegNO_BOX.Text);
                int id = Convert.ToInt32(ID.ExecuteScalar());

                SqlCommand person = new SqlCommand("update Person set FirstName = @FirstName,LastName = @LastName,Contact = @Contact,Email = @Email,DateOfBirth = @DateOfBirth,Gender = @Gender from Person where Id = @Id", con);
                person.Parameters.AddWithValue("@Id", id);
                SqlCommand gender = new SqlCommand("select id from lookup where value = @value", con);
                gender.Parameters.AddWithValue("@value", comboBox1.Text);
                int gend = Convert.ToInt32(gender.ExecuteScalar());

                person.Parameters.AddWithValue("@FirstName", Fname_Box.Text);
                person.Parameters.AddWithValue("@LastName", Lname_Box.Text);
                person.Parameters.AddWithValue("@Contact", Contact_Box.Text);
                person.Parameters.AddWithValue("@Email", Email_Box.Text);
                person.Parameters.AddWithValue("@DateOfBirth", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                person.Parameters.AddWithValue("@Gender", gend);
                person.ExecuteNonQuery();


                MessageBox.Show("Successfully Updated");

                this.Close();
            }
        }

        

        private void Fname_Box_Validating_1(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Fname_Box.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                Fname_Box.Focus();
                errorProvider_Fname.SetError(Fname_Box, "Please Enter Your First Name");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Fname.SetError(Fname_Box, null);
                //Add_Button.Enabled = true;

            }
        }

        private void Email_Box_Validating_1(object sender, CancelEventArgs e)
        {
            if (!(Email_Box.Text.Contains("@gmail.com")))
            {
                
                e.Cancel = true;
                Email_Box.Focus();
                errorProvider_Email.SetError(Email_Box, "Please Enter Valid Email");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Email.SetError(Email_Box, null);
                

            }
        }

        private void RegNO_BOX_Validating_1(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(RegNO_BOX.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                RegNO_BOX.Focus();
                errorProvider_regno.SetError(RegNO_BOX, "Please Enter Your Registration No");
            }
            else
            {
                e.Cancel = false;
                errorProvider_regno.SetError(RegNO_BOX, null);
                //Add_Button.Enabled = true;
                
            }
        }
        /*public void datashow()
        {
           
            
            var con = Configuration.getInstance().getConnection();
            SqlCommand load = new SqlCommand("select * from Person join Student on Person.ID = Student.ID where Student.Id = @Id", con);
            ID.Parameters.AddWithValue("@Id", );
            int id = Convert.ToInt32(ID.ExecuteScalar());
        }*/
        private void UpdateStudent_Load(object sender, EventArgs e)
        {
            
            var con = Configuration.getInstance().getConnection();
            SqlCommand load = new SqlCommand("select * from Person join Student on Person.ID = Student.ID where Student.Id = @Id", con);
            load.Parameters.AddWithValue("@Id",id );
            //con.Open();
            using (SqlDataReader sdr = load.ExecuteReader())
            {
                sdr.Read();
                RegNO_BOX.Text = sdr["RegistrationNo"].ToString();
                Fname_Box.Text = sdr["FirstName"].ToString();
                Lname_Box.Text = sdr["LastName"].ToString();
                Contact_Box.Text = sdr["Contact"].ToString();
                Email_Box.Text = sdr["Email"].ToString();
                dateTimePicker1.Text = sdr["DateOfBirth"].ToString();
                SqlCommand gend = new SqlCommand("select value from lookup where Id = @Id", con);
                gend.Parameters.AddWithValue("@Id", int.Parse(sdr["Gender"].ToString()));
                sdr.Close();
                string gender = Convert.ToString(gend.ExecuteScalar());
                comboBox1.Text = gender;


            }
            
        }
    }
}
