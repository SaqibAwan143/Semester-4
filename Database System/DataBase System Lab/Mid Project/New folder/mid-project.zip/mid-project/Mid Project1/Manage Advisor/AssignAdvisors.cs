﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project1.Manage_Advisor
{
    public partial class AssignAdvisors : Form
    {
        public AssignAdvisors()
        {
            InitializeComponent();
        }
        public int G_id, P_id;
        public void GroupIdLoad()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Person join Advisor A on Person.Id = A.Id ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt; 

        }
        public void Projectsload()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Project ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView2.DataSource = dt;

        }

        private void AssignAdvisors_Load(object sender, EventArgs e)
        {
            GroupIdLoad();
            Projectsload();
        }

        private void dataGridView2_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            P_id = int.Parse(dataGridView2.SelectedRows[0].Cells[0].Value.ToString());
        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand role = new SqlCommand("select id from lookup where value = @value", con);
                role.Parameters.AddWithValue("@value", comboBox1.Text);
                int Arole = Convert.ToInt32(role.ExecuteScalar());


                SqlCommand person = new SqlCommand("Insert into ProjectAdvisor values (@AdvisorId,@ProjectId,@AdvisorRole,@AssignmentDate)", con);
                person.Parameters.AddWithValue("@AdvisorId", G_id);
                person.Parameters.AddWithValue("@ProjectId", P_id);
                person.Parameters.AddWithValue("@AdvisorRole", Arole);
                person.Parameters.AddWithValue("@AssignmentDate", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                person.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            G_id = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          //  G_id = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }


    }
}
