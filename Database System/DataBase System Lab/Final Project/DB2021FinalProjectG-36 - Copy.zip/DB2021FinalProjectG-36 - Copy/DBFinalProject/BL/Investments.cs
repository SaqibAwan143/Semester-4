﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBFinalProject.BL
{
    internal class Investments
    {
        int personId; 
        int amount;
        int startupId;
        string date;

    }
}
