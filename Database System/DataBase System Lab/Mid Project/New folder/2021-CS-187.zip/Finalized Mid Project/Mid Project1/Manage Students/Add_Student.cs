﻿using Mid_Project1;
using FakeItEasy;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace Mid_Project1
{
    public partial class Add_Student : Form
    {
        public Add_Student()
        {
            InitializeComponent();
        }

       

        private void RegNO_BOX_TextChanged(object sender, EventArgs e)
        {

            
        }
      
        private void RegNO_BOX_KeyPress(object sender, KeyPressEventArgs e)
        {
          /*  if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
       (e.KeyChar != '.'))
            {
                e.Handled = true;
                Regno_eroor_lbl.Text = "Only Numbers are Allowed !*";
            }
            else
            {
                Regno_eroor_lbl.Text = "";
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }*/
        }

        private void RegNO_BOX_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(RegNO_BOX.Text))
            {
               // Add_Button.Enabled = false;
                e.Cancel = true;
                RegNO_BOX.Focus();
                errorProvider_regno.SetError(RegNO_BOX, "Please Enter Your Registration No");
            }
            else
            {
                e.Cancel = false;
                errorProvider_regno.SetError(RegNO_BOX, null);
                //Add_Button.Enabled = true;

            }
        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                //MessageBox.Show(RegNO_BOX.Text,"Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
                /*Regno_eroor_lbl.Text = "Please enter registration no";*/
                if(comboBox1.Text.Contains("NULL"))
                {
                    comboBox1.Text = "Male";
                }
                var con = Configuration.getInstance().getConnection();
                SqlCommand person = new SqlCommand("Insert into Person values (@FirstName,@LastName,@Contact,@Email,@DateOfBirth,@Gender)", con);

                SqlCommand gender = new SqlCommand("select id from lookup where value = @value", con);
                gender.Parameters.AddWithValue("@value", comboBox1.Text);
                int gend = Convert.ToInt32(gender.ExecuteScalar());

                person.Parameters.AddWithValue("@FirstName", Fname_Box .Text);
                person.Parameters.AddWithValue("@LastName", Lname_Box.Text);
                person.Parameters.AddWithValue("@Contact", Contact_Box.Text);
                person.Parameters.AddWithValue("@Email", Email_Box.Text);
                person.Parameters.AddWithValue("@DateOfBirth", dateTimePicker1.Value.ToString("MM/dd/yyyy"));
                person.Parameters.AddWithValue("@Gender", gend);
                person.ExecuteNonQuery();

                SqlCommand ID = new SqlCommand("select max(Id) from Person", con);
                int id = Convert.ToInt32(ID.ExecuteScalar());

                SqlCommand student = new SqlCommand("Insert into Student values (@Id,@RegistrationNo)", con);
                student.Parameters.AddWithValue("@Id", id);
                student.Parameters.AddWithValue("@RegistrationNo", RegNO_BOX.Text);
                student.ExecuteNonQuery();

                MessageBox.Show("Successfully saved");
                
                this.Close();
                //ManageStudent manage = new ManageStudent();
                
            }
                
        }

        private void Fname_Box_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(Fname_Box.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                Fname_Box.Focus();
                errorProvider_Fname.SetError(Fname_Box, "Please Enter Your First Name");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Fname.SetError(Fname_Box, null);
                //Add_Button.Enabled = true;

            }
        }

        private void Fname_Box_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void Email_Box_Validating(object sender, CancelEventArgs e)
        {
            //if (string.IsNullOrEmpty(Email_Box.Text))
            if(!(Email_Box.Text.Contains("@gmail.com")))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                Email_Box.Focus();
                errorProvider_Email.SetError(Email_Box, "Please Enter Valid Email");
            }
            else
            {
                e.Cancel = false;
                errorProvider_Email.SetError(Email_Box, null);
                //Add_Button.Enabled = true;

            }
        }

        private void Email_Box_Leave(object sender, EventArgs e)
        {
            //string pattern = ^([0 - 9A - za - Z]([-\\.\\w] *[0 - 9a - zA - Z]) *@([0 - 9a - zA - Z][-\\w] *[0 - 9a - zA - Z]\\.)+[a - zA - Z]{ 2,9})$;
           // if (Regex.IsMatch(Email_Box.Text, pattern)) ;
        }
    }
}
