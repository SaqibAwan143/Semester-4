﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBFinalProject.BL
{
    internal class Startup
    {
        string title;
        string description;
        int totalworth;
        int minimuminvestment;
        string createdate;
    }
}
