﻿namespace Mid_Project1
{
    partial class AddAdvisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DesignationLabel = new System.Windows.Forms.Label();
            this.FnameLabel = new System.Windows.Forms.Label();
            this.LNameLabel = new System.Windows.Forms.Label();
            this.ContLabel = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.DOBLabel = new System.Windows.Forms.Label();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.Contact = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.AddButton = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.desig_Combo = new System.Windows.Forms.ComboBox();
            this.Salary = new System.Windows.Forms.TextBox();
            this.errorProvider_Fname = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Email = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider_Desig = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Fname)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Email)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Desig)).BeginInit();
            this.SuspendLayout();
            // 
            // DesignationLabel
            // 
            this.DesignationLabel.AutoSize = true;
            this.DesignationLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.DesignationLabel, 2);
            this.DesignationLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DesignationLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DesignationLabel.Location = new System.Drawing.Point(83, 45);
            this.DesignationLabel.Name = "DesignationLabel";
            this.DesignationLabel.Size = new System.Drawing.Size(154, 45);
            this.DesignationLabel.TabIndex = 1;
            this.DesignationLabel.Text = "Designation";
            this.DesignationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FnameLabel
            // 
            this.FnameLabel.AutoSize = true;
            this.FnameLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.FnameLabel, 2);
            this.FnameLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FnameLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FnameLabel.Location = new System.Drawing.Point(83, 90);
            this.FnameLabel.Name = "FnameLabel";
            this.FnameLabel.Size = new System.Drawing.Size(154, 45);
            this.FnameLabel.TabIndex = 2;
            this.FnameLabel.Text = "First Name";
            this.FnameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LNameLabel
            // 
            this.LNameLabel.AutoSize = true;
            this.LNameLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.LNameLabel, 2);
            this.LNameLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LNameLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNameLabel.Location = new System.Drawing.Point(83, 135);
            this.LNameLabel.Name = "LNameLabel";
            this.LNameLabel.Size = new System.Drawing.Size(154, 45);
            this.LNameLabel.TabIndex = 3;
            this.LNameLabel.Text = "Last Name";
            this.LNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ContLabel
            // 
            this.ContLabel.AutoSize = true;
            this.ContLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.ContLabel, 2);
            this.ContLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContLabel.Location = new System.Drawing.Point(83, 180);
            this.ContLabel.Name = "ContLabel";
            this.ContLabel.Size = new System.Drawing.Size(154, 45);
            this.ContLabel.TabIndex = 4;
            this.ContLabel.Text = "Contact";
            this.ContLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.EmailLabel, 2);
            this.EmailLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EmailLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmailLabel.Location = new System.Drawing.Point(83, 225);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(154, 45);
            this.EmailLabel.TabIndex = 5;
            this.EmailLabel.Text = "Email";
            this.EmailLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DOBLabel
            // 
            this.DOBLabel.AutoSize = true;
            this.DOBLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.DOBLabel, 2);
            this.DOBLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DOBLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DOBLabel.Location = new System.Drawing.Point(83, 270);
            this.DOBLabel.Name = "DOBLabel";
            this.DOBLabel.Size = new System.Drawing.Size(154, 45);
            this.DOBLabel.TabIndex = 6;
            this.DOBLabel.Text = "Date Of Birth";
            this.DOBLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.GenderLabel, 2);
            this.GenderLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GenderLabel.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderLabel.Location = new System.Drawing.Point(83, 315);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(154, 45);
            this.GenderLabel.TabIndex = 7;
            this.GenderLabel.Text = "Gender";
            this.GenderLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FirstName
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.FirstName, 3);
            this.FirstName.Dock = System.Windows.Forms.DockStyle.Right;
            this.FirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstName.Location = new System.Drawing.Point(255, 93);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(222, 29);
            this.FirstName.TabIndex = 10;
            this.FirstName.Validating += new System.ComponentModel.CancelEventHandler(this.FirstName_Validating);
            // 
            // LastName
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.LastName, 3);
            this.LastName.Dock = System.Windows.Forms.DockStyle.Right;
            this.LastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastName.Location = new System.Drawing.Point(255, 138);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(222, 29);
            this.LastName.TabIndex = 11;
            // 
            // Contact
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.Contact, 3);
            this.Contact.Dock = System.Windows.Forms.DockStyle.Right;
            this.Contact.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contact.Location = new System.Drawing.Point(255, 183);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(222, 29);
            this.Contact.TabIndex = 12;
            // 
            // Email
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.Email, 3);
            this.Email.Dock = System.Windows.Forms.DockStyle.Right;
            this.Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(255, 228);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(222, 29);
            this.Email.TabIndex = 13;
            this.Email.Validating += new System.ComponentModel.CancelEventHandler(this.Email_Validating);
            // 
            // dateTimePicker1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.dateTimePicker1, 3);
            this.dateTimePicker1.Dock = System.Windows.Forms.DockStyle.Right;
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(255, 273);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(222, 20);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // comboBox1
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.comboBox1, 3);
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Male",
            "Female",
            "NULL"});
            this.comboBox1.Location = new System.Drawing.Point(254, 318);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(223, 32);
            this.comboBox1.TabIndex = 17;
            // 
            // AddButton
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.AddButton, 2);
            this.AddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddButton.Location = new System.Drawing.Point(643, 363);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(139, 39);
            this.AddButton.TabIndex = 18;
            this.AddButton.Text = "Add";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.tableLayoutPanel1.ColumnCount = 10;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Controls.Add(this.AddButton, 8, 8);
            this.tableLayoutPanel1.Controls.Add(this.DesignationLabel, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.FnameLabel, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.LNameLabel, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.ContLabel, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.EmailLabel, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.DOBLabel, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.GenderLabel, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.desig_Combo, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.FirstName, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.LastName, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.Contact, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.Email, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.dateTimePicker1, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.comboBox1, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.Salary, 3, 8);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Lime;
            this.tableLayoutPanel1.SetColumnSpan(this.label1, 2);
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(83, 360);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 45);
            this.label1.TabIndex = 20;
            this.label1.Text = "Salary";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // desig_Combo
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.desig_Combo, 3);
            this.desig_Combo.Dock = System.Windows.Forms.DockStyle.Right;
            this.desig_Combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.desig_Combo.FormattingEnabled = true;
            this.desig_Combo.Items.AddRange(new object[] {
            "Professor",
            "Associate Professor",
            "Assisstant Professor",
            "Industry Professional",
            "Lecturer"});
            this.desig_Combo.Location = new System.Drawing.Point(257, 48);
            this.desig_Combo.Name = "desig_Combo";
            this.desig_Combo.Size = new System.Drawing.Size(220, 32);
            this.desig_Combo.TabIndex = 19;
            this.desig_Combo.Validating += new System.ComponentModel.CancelEventHandler(this.comboBox2_Validating);
            // 
            // Salary
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.Salary, 3);
            this.Salary.Dock = System.Windows.Forms.DockStyle.Right;
            this.Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salary.Location = new System.Drawing.Point(256, 363);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(221, 29);
            this.Salary.TabIndex = 21;
            // 
            // errorProvider_Fname
            // 
            this.errorProvider_Fname.ContainerControl = this;
            // 
            // errorProvider_Email
            // 
            this.errorProvider_Email.ContainerControl = this;
            // 
            // errorProvider_Desig
            // 
            this.errorProvider_Desig.ContainerControl = this;
            // 
            // AddAdvisor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "AddAdvisor";
            this.Text = "AddAdvisor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Fname)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Email)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider_Desig)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label DesignationLabel;
        private System.Windows.Forms.Label FnameLabel;
        private System.Windows.Forms.Label LNameLabel;
        private System.Windows.Forms.Label ContLabel;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.Label DOBLabel;
        private System.Windows.Forms.Label GenderLabel;
        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox Contact;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.ComboBox desig_Combo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Salary;
        private System.Windows.Forms.ErrorProvider errorProvider_Fname;
        private System.Windows.Forms.ErrorProvider errorProvider_Email;
        private System.Windows.Forms.ErrorProvider errorProvider_Desig;
    }
}