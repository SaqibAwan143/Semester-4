﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project1
{
    public partial class ManageAdvisors : Form
    {
        public ManageAdvisors()
        {
            InitializeComponent();
        }
        int id;
        private void AddButton_Click(object sender, EventArgs e)
        {
            AddAdvisor add = new AddAdvisor();
            add.ShowDialog();
        }

        private void ManageAdvisors_Load(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from person join Advisor on Advisor.Id = person.id ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from person join Advisor on Advisor.Id = person.id ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            UpdateAdvisor up = new UpdateAdvisor(id);
            up.ShowDialog();
        }

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            //SqlCommand cmd = new SqlCommand("Select * from person join student on student.Id = person.id ", con);
            SqlDataAdapter adapt = new SqlDataAdapter("select * from Person join Advisor on Advisor.Id = Person.Id where FirstName like '" + SearchTextBox.Text + "%'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            id = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }
    }
}
