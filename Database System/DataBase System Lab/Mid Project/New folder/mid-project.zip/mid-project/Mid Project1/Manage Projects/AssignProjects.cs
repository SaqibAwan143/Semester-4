﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Mid_Project1.Manage_Projects
{
    public partial class AssignProjects : Form
    {
        public AssignProjects()
        {
            InitializeComponent();
        }
        public int P_id;
        private void AssignProjects_Load(object sender, EventArgs e)
        {
            GroupIdLoad();
            loadProjects();
        }
        public void loadProjects()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Project ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        public void GroupIdLoad()
        {
            var con = Configuration.getInstance().getConnection();
            SqlDataReader myReader1 = null;
            SqlCommand myCommand1 = new SqlCommand("select Id from dbo.[Group]", con);
            myReader1 = myCommand1.ExecuteReader();
            while (myReader1.Read())
            {
                comboBox1.Items.Add((int)myReader1["Id"]);
            }
            myReader1.Close();

        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            P_id = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }

        private void comboBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox1.Text))
            {
                e.Cancel = true;
                comboBox1.Focus();
                errorProvider1.SetError(comboBox1, "Please Select Group Id");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(comboBox1, null);
            }
        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateChildren(ValidationConstraints.Enabled))
                {

                    var con = Configuration.getInstance().getConnection();
                    SqlCommand Projects = new SqlCommand("Insert into GroupProject values (@ProjectId,@GroupId,@AssignmentDate)", con);
                    Projects.Parameters.AddWithValue("@ProjectId", P_id);
                    Projects.Parameters.AddWithValue("@Groupid", int.Parse(comboBox1.Text));
                    Projects.Parameters.AddWithValue("@AssignmentDate", dateTimePicker1.Value.ToString("MM/dd/yyyy"));

                    Projects.ExecuteNonQuery();
                    MessageBox.Show("Successfully saved");

                }

            }
            catch
            {
                MessageBox.Show("Please Select Project");
            }
        }
    }
}
