﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project1.Manage_Projects
{
    public partial class UpdateProject : Form
    {
        public int id;
        public UpdateProject(int i)
        {
            InitializeComponent();
            id = i;
        }

        private void title_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(title.Text))
            {
                // Add_Button.Enabled = false;
                e.Cancel = true;
                title.Focus();
                errorProvider.SetError(title, "Please Enter Title");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(title, null);
                //Add_Button.Enabled = true;

            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand ID = new SqlCommand("select Id from Project where Id = @Id", con);
                ID.Parameters.AddWithValue("@Id", id);
                int idi = Convert.ToInt32(ID.ExecuteScalar());

                SqlCommand person = new SqlCommand("update Project set @Description = @Description,Title = @Title from Project where Id = @Id", con);
                person.Parameters.AddWithValue("@Id", idi);
                

                person.Parameters.AddWithValue("@Description", richTextBox1.Text);
                person.Parameters.AddWithValue("@Title", title.Text);
                person.ExecuteNonQuery();


                MessageBox.Show("Successfully Updated");

                this.Close();
            }
        }

        private void UpdateProject_Load(object sender, EventArgs e)
        {
            try
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand load = new SqlCommand("select * from Project where Id = @Id", con);
                load.Parameters.AddWithValue("@Id", id);
                //con.Open();
                using (SqlDataReader sdr = load.ExecuteReader())
                {
                    sdr.Read();
                    richTextBox1.Text = sdr["Description"].ToString();
                    title.Text = sdr["Title"].ToString();
                    sdr.Close();
                }
            }
            catch
            {
                MessageBox.Show("Please select project to update");
                this.Close();
            }
            
        }
    }
}
