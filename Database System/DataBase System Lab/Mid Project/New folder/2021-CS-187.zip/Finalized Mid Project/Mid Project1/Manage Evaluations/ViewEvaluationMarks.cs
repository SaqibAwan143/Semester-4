﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project1.Manage_Evaluations
{
    public partial class ViewEvaluationMarks : Form
    {
        public ViewEvaluationMarks()
        {
            InitializeComponent();
        }
        public int E_Id; 
        public void LoadGroupEvaluations()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from GroupEvaluation ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void ViewEvaluationMarks_Load(object sender, EventArgs e)
        {
            LoadGroupEvaluations();
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            E_Id = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }

        private void UPdate_Button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
